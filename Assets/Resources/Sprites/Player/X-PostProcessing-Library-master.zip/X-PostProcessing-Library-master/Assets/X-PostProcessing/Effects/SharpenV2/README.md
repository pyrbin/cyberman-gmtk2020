
# SharpenV2

## Source Code List
- [Shader Code](Shader/SharpenV2.shader)
- [C# Code](SharpenV2.cs)
- [Editor Code](Editor/SharpenV2Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/ImageProcessing/SharpenV2/SharpenV2Property.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/ImageProcessing/SharpenV2/SharpenV2.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/ImageProcessing/SharpenV2/SharpenV2.gif)