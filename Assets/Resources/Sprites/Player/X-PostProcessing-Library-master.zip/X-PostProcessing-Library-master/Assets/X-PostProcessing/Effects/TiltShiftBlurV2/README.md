
# Tilt Shift BlurV2

## Source Code List
- [Shader Code](Shader/TiltShiftBlurV2.shader)
- [C# Code](TiltShiftBlurV2.cs)
- [Editor Code](Editor/TiltShiftBlurV2Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TiltShiftBlurV2/TiltShiftBlurV2Property.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TiltShiftBlurV2/TiltShiftBlurV2.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TiltShiftBlurV2/TiltShiftBlurV2-1.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TiltShiftBlurV2/TiltShiftBlurV2-2.gif)