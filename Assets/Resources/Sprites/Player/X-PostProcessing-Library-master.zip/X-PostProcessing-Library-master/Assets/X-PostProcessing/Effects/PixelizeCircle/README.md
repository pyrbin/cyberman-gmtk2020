
# Pixelize Circle

## Source Code List
- [Shader Code](Shader/PixelizeCircle.shader)
- [C# Code](PixelizeCircle.cs)
- [Editor Code](Editor/PixelizeCircleEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeCircle/PixelizeCircleProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeCircle/PixelizeCircle.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeCircle/PixelizeCircle.gif)