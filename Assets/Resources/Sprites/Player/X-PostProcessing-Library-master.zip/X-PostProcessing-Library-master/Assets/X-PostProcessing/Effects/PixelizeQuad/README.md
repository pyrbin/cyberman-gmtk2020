
# Pixelize Quad

## Source Code List
- [Shader Code](Shader/PixelizeQuad.shader)
- [C# Code](PixelizeQuad.cs)
- [Editor Code](Editor/PixelizeQuadEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeQuad/PixelizeQuadProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeQuad/PixelizeQuad.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeQuad/PixelizeQuad.gif)