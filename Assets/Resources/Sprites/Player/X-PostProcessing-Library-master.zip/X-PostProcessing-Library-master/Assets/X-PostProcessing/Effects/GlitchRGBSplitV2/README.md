
# GlitchRGBSplitV2

## Source Code List
- [Shader Code](Shader/GlitchRGBSplitV2.shader)
- [C# Code](GlitchRGBSplitV2.cs)
- [Editor Code](Editor/GlitchRGBSplitV2Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV2/GlitchRGBSplitV2.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV2/GlitchRGBSplitV2-1.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV2/GlitchRGBSplitV2.gif)
