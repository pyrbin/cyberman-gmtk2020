
# Iris Blur V2

## Source Code List
- [Shader Code](Shader/IrisBlurV2.shader)
- [C# Code](IrisBlurV2.cs)
- [Editor Code](Editor/IrisBlurV2Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/IrisBlurV2/IrisBlurV2Property.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/IrisBlurV2/IrisBlurV2.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/IrisBlurV2/IrisBlurV2-1.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/IrisBlurV2/IrisBlurV2-1.gif)