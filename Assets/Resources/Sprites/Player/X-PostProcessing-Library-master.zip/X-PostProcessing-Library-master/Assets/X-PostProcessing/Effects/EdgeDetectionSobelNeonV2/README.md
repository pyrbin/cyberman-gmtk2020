
# EdgeDetectionSobelNeonV2

## Source Code List
- [Shader Code](Shader/EdgeDetectionSobelNeonV2.shader)
- [C# Code](EdgeDetectionSobelNeonV2.cs)
- [Editor Code](Editor/EdgeDetectionSobelNeonV2Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobelNeonV2/EdgeDetectionSobelNeonV2Property.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobelNeonV2/EdgeDetectionSobelNeonV2.jpg)


![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobelNeonV2/EdgeDetectionSobelNeonV2.gif)

