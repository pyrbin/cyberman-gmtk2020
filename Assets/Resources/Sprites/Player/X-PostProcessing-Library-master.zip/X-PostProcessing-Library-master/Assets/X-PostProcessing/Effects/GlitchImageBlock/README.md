
# GlitchImageBlock

## Source Code List
- [Shader Code](Shader/GlitchImageBlock.shader)
- [C# Code](GlitchImageBlock.cs)
- [Editor Code](Editor/GlitchImageBlockEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchImageBlock/GlitchImageBlock.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchImageBlock/GlitchImageBlock-2.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchImageBlock/GlitchImageBlock.gif)
