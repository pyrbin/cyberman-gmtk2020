
# Bokeh Blur

## Source Code List
- [Shader Code](Shader/BokehBlur.shader)
- [C# Code](BokehBlur.cs)
- [Editor Code](Editor/BokehBlurEditor.cs)

## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/BokehBlur/BokehBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/BokehBlur/BokehBlur.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/BokehBlur/BokehBlur.gif)