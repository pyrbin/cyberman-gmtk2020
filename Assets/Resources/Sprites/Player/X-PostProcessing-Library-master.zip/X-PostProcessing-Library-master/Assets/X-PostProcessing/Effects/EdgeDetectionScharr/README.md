
# Edge Detection Scharr

## Source Code List
- [Shader Code](Shader/EdgeDetectionScharr.shader)
- [C# Code](EdgeDetectionScharr.cs)
- [Editor Code](Editor/EdgeDetectionScharrEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharr/EdgeDetectionScharrProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharr/EdgeDetectionScharr1.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharr/EdgeDetectionScharr2.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharr/EdgeDetectionScharr1.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharr/EdgeDetectionScharr2.gif)