
# Dual Gaussian Blur

## Source Code List
- [Shader Code](Shader/DualGaussianBlur.shader)
- [C# Code](DualGaussianBlur.cs)
- [Editor Code](Editor/DualGaussianBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualGaussianBlur/DualGaussianBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualGaussianBlur/DualGaussianBlur.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualGaussianBlur/DualGaussianBlur.gif)