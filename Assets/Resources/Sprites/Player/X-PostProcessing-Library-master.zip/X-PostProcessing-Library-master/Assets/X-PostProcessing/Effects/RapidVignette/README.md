
# RapidVignette

## Source Code List
- [Shader Code](Shader/RapidVignette.shader)
- [C# Code](RapidVignette.cs)
- [Editor Code](Editor/RapidVignetteEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidVignette/RapidVignetteProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidVignette/RapidVignette.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidVignette/RapidVignette.gif)