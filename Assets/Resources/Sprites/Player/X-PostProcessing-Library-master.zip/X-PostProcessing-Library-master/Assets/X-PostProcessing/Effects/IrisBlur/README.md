# Iris Blur

## Source Code List
- [Shader Code](Shader/IrisBlur.shader)
- [C# Code](IrisBlur.cs)
- [Editor Code](Editor/IrisBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/IrisBlur/IrisBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/IrisBlur/IrisBlur.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/IrisBlur/IrisBlur.gif)