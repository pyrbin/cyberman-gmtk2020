
# Dual Box Blur

## Source Code List
- [Shader Code](Shader/DualBoxBlur.shader)
- [C# Code](DualBoxBlur.cs)
- [Editor Code](Editor/DualBoxBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualBoxBlur/DualBoxBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualBoxBlur/DualBoxBlur.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualBoxBlur/DualBoxBlur.gif)