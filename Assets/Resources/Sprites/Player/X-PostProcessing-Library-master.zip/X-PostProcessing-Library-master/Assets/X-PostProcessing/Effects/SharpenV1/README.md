
# SharpenV1

## Source Code List
- [Shader Code](Shader/SharpenV1.shader)
- [C# Code](SharpenV1.cs)
- [Editor Code](Editor/SharpenV1Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/ImageProcessing/SharpenV1/SharpenV1Property.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/ImageProcessing/SharpenV1/SharpenV1.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/ImageProcessing/SharpenV1/SharpenV1.gif)