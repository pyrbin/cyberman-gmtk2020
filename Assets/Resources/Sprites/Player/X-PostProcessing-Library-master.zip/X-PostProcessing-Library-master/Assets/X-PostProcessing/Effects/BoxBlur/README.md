
# Box Blur

## Source Code List
- [Shader Code](Shader/BoxBlur.shader)
- [C# Code](BoxBlur.cs)
- [Editor Code](Editor/BoxBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/BoxBlur/BoxBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/BoxBlur/BoxBlur.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/BoxBlur/BoxBlur.gif)