
# Edge Detection Sobel

## Source Code List
- [Shader Code](Shader/EdgeDetectionSobel.shader)
- [C# Code](EdgeDetectionSobel.cs)
- [Editor Code](Editor/EdgeDetectionSobelEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobel/EdgeDetectionSobelProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobel/EdgeDetectionSobel1.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobel/EdgeDetectionSobel2.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobel/EdgeDetectionSobel1.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobel/EdgeDetectionSobel2.gif)