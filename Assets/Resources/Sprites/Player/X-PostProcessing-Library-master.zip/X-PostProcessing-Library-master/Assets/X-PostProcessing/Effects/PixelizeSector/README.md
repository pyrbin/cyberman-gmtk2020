
# Pixelize Sector

## Source Code List
- [Shader Code](Shader/PixelizeSector.shader)
- [C# Code](PixelizeSector.cs)
- [Editor Code](Editor/PixelizeSectorEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeSector/PixelizeSectorProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeSector/PixelizeSector.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeSector/PixelizeSector.gif)