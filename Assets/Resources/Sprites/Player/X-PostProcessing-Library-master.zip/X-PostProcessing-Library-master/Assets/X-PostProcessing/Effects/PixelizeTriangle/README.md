﻿
# Pixelize Triangle

## Source Code List
- [Shader Code](Shader/PixelizeTriangle.shader)
- [C# Code](PixelizeTriangle.cs)
- [Editor Code](Editor/PixelizeTriangleEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeTriangle/PixelizeTriangleProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeTriangle/PixelizeTriangle.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeTriangle/PixelizeTriangle.gif)