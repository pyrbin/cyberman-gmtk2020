
# Edge Detection Roberts

## Source Code List
- [Shader Code](Shader/EdgeDetectionRoberts.shader)
- [C# Code](EdgeDetectionRoberts.cs)
- [Editor Code](Editor/EdgeDetectionRobertsEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionRoberts/EdgeDetectionRobertsProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionRoberts/EdgeDetectionRoberts1.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionRoberts/EdgeDetectionRoberts2.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionRoberts/EdgeDetectionRoberts1.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionRoberts/EdgeDetectionRoberts2.gif)