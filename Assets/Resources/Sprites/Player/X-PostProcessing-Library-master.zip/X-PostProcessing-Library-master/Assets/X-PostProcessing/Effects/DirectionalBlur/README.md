
# Directional Blur

## Source Code List
- [Shader Code](Shader/DirectionalBlur.shader)
- [C# Code](DirectionalBlur.cs)
- [Editor Code](Editor/DirectionalBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DirectionalBlur/DirectionalBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DirectionalBlur/DirectionalBlur.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DirectionalBlur/DirectionalBlur-1.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DirectionalBlur/DirectionalBlur-2.gif)
