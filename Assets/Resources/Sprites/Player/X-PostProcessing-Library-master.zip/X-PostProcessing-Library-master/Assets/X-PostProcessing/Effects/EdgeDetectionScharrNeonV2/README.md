
# Edge Detection Scharr Neon V2

## Source Code List
- [Shader Code](Shader/EdgeDetectionScharrNeonV2.shader)
- [C# Code](EdgeDetectionScharrNeonV2.cs)
- [Editor Code](Editor/EdgeDetectionScharrNeonV2Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharrNeonV2/EdgeDetectionScharrNeonV2Property.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharrNeonV2/EdgeDetectionScharrNeonV2.jpg)


![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharrNeonV2/EdgeDetectionScharrNeonV2.gif)
