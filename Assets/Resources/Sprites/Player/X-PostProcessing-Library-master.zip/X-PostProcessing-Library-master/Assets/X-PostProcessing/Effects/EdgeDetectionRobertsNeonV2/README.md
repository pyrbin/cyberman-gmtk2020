
# Edge Detection Roberts Neon V2

## Source Code List
- [Shader Code](Shader/EdgeDetectionRobertsNeonV2.shader)
- [C# Code](EdgeDetectionRobertsNeonV2.cs)
- [Editor Code](Editor/EdgeDetectionRobertsNeonV2Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionRobertsNeonV2/EdgeDetectionRobertsNeonV2Property.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionRobertsNeonV2/EdgeDetectionRobertsNeonV2.jpg)


![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionRobertsNeonV2/EdgeDetectionRobertsNeonV2.gif)