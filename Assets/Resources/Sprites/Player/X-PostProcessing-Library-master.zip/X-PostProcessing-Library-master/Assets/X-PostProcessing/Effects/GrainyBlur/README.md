
# Grainy Blur

## Source Code List
- [Shader Code](Shader/GrainyBlur.shader)
- [C# Code](GrainyBlur.cs)
- [Editor Code](Editor/GrainyBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/GrainyBlur/GrainyBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/GrainyBlur/GrainyBlur.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/GrainyBlur/GrainyBlur.gif)