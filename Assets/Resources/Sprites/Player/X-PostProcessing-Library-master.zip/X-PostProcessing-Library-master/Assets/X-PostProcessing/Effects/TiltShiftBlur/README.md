
# Tilt Shift Blur

## Source Code List
- [Shader Code](Shader/TiltShiftBlur.shader)
- [C# Code](TiltShiftBlur.cs)
- [Editor Code](Editor/TiltShiftBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TiltShiftBlur/TiltShiftBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TiltShiftBlur/TiltShiftBlur.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TiltShiftBlur/TiltShiftBlur.gif)