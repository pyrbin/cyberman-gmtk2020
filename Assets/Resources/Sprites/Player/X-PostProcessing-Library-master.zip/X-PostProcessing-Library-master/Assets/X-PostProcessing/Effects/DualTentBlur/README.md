
# Dual Tent Blur

## Source Code List
- [Shader Code](Shader/DualTentBlur.shader)
- [C# Code](DualTentBlur.cs)
- [Editor Code](Editor/DualTentBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualTentBlur/DualTentBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualTentBlur/DualTentBlur.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualTentBlur/DualTentBlur.gif)