
# RapidOldTVVignetteV2

## Source Code List
- [Shader Code](Shader/RapidOldTVVignetteV2.shader)
- [C# Code](RapidOldTVVignetteV2.cs)
- [Editor Code](Editor/RapidOldTVVignetteV2Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidOldTVVignetteV2/RapidOldTVVignetteV2Property.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidOldTVVignetteV2/RapidOldTVVignetteV2.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidOldTVVignetteV2/RapidOldTVVignetteV2.gif)