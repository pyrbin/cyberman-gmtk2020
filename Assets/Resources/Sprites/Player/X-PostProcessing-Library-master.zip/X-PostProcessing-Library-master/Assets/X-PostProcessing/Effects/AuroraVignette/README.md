
# AuroraVignette

## Source Code List
- [Shader Code](Shader/AuroraVignette.shader)
- [C# Code](AuroraVignette.cs)
- [Editor Code](Editor/AuroraVignetteEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/AuroraVignette/AuroraVignetteProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/AuroraVignette/AuroraVignette.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/AuroraVignette/AuroraVignette.gif)