
# GlitchRGBSplitV5

## Source Code List
- [Shader Code](Shader/GlitchRGBSplitV5.shader)
- [C# Code](GlitchRGBSplitV5.cs)
- [Editor Code](Editor/GlitchRGBSplitV5Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV5/GlitchRGBSplitV5.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV5/GlitchRGBSplitV5-2.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV5/GlitchRGBSplitV5.gif)
