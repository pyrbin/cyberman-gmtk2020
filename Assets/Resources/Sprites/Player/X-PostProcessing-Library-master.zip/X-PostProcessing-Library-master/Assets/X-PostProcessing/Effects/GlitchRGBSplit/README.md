
# GlitchRGBSplit

## Source Code List
- [Shader Code](Shader/GlitchRGBSplit.shader)
- [C# Code](GlitchRGBSplit.cs)
- [Editor Code](Editor/GlitchRGBSplitEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplit/GlitchRGBSplit.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplit/GlitchRGBSplit.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplit/GlitchRGBSplit-1.gif)
