
# Kawase Blur

## Source Code List
- [Shader Code](Shader/KawaseBlur.shader)
- [C# Code](KawaseBlur.cs)
- [Editor Code](Editor/KawaseBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/KawaseBlur/KawaseBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/KawaseBlur/KawaseBlur.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/KawaseBlur/KawaseBlur.gif)