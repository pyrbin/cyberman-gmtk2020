
# Pixelize Hexagon Grid

## Source Code List
- [Shader Code](Shader/PixelizeHexagonGrid.shader)
- [C# Code](PixelizeHexagonGrid.cs)
- [Editor Code](Editor/PixelizeHexagonGridEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeHexagonGrid/PixelizeHexagonGridProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeHexagonGrid/PixelizeHexagonGrid.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeHexagonGrid/PixelizeHexagonGrid.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeHexagonGrid/PixelizeHexagonGrid-2.gif)