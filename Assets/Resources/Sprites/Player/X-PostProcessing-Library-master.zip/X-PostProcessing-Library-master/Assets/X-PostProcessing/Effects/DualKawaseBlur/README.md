
# Dual Kawase Blur

## Source Code List
- [Shader Code](Shader/DualKawaseBlur.shader)
- [C# Code](DualKawaseBlur.cs)
- [Editor Code](Editor/DualKawaseBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualKawaseBlur/DualKawaseBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualKawaseBlur/DualKawaseBlur.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/DualKawaseBlur/DualKawaseBlur.gif)