
# EdgeDetectionScharrNeon

## Source Code List
- [Shader Code](Shader/EdgeDetectionScharrNeon.shader)
- [C# Code](EdgeDetectionScharrNeon.cs)
- [Editor Code](Editor/EdgeDetectionScharrNeonEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharrNeon/EdgeDetectionScharrNeonProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharrNeon/EdgeDetectionScharrNeon.jpg)


![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionScharrNeon/EdgeDetectionScharrNeon.gif)
