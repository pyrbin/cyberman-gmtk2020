
# RapidOldTVVignette

## Source Code List
- [Shader Code](Shader/RapidOldTVVignette.shader)
- [C# Code](RapidOldTVVignette.cs)
- [Editor Code](Editor/RapidOldTVVignetteEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidOldTVVignette/RapidOldTVVignetteProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidOldTVVignette/RapidOldTVVignette.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidOldTVVignette/RapidOldTVVignette.gif)