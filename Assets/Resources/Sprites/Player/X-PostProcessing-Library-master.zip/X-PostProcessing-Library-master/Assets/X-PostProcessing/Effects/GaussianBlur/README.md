
# Gaussian Blur

## Source Code List
- [Shader Code](Shader/GaussianBlur.shader)
- [C# Code](GaussianBlur.cs)
- [Editor Code](Editor/GaussianBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/GaussianBlur/GaussianBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/GaussianBlur/GaussianBlur.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/GaussianBlur/GaussianBlur.gif)
