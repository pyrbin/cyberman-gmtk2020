
# GlitchRGBSplitV3

## Source Code List
- [Shader Code](Shader/GlitchRGBSplitV3.shader)
- [C# Code](GlitchRGBSplitV3.cs)
- [Editor Code](Editor/GlitchRGBSplitV3Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV3/GlitchRGBSplitV3.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV3/GlitchRGBSplitV3-2.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV3/GlitchRGBSplitV3.gif)
