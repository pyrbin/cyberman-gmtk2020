
# GlitchDigitalStripe

## Source Code List
- [Shader Code](Shader/GlitchDigitalStripe.shader)
- [C# Code](GlitchDigitalStripe.cs)
- [Editor Code](Editor/GlitchDigitalStripeEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchDigitalStripe/GlitchDigitalStripe.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchDigitalStripe/GlitchDigitalStripe1.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchDigitalStripe/DigitalStripeGlitch2.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchDigitalStripe/GlitchDigitalStripe.gif)
