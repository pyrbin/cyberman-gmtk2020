
# EdgeDetectionSobelNeon

## Source Code List
- [Shader Code](Shader/EdgeDetectionSobelNeon.shader)
- [C# Code](EdgeDetectionSobelNeon.cs)
- [Editor Code](Editor/EdgeDetectionSobelNeonEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobelNeon/EdgeDetectionSobelNeonProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobelNeon/EdgeDetectionSobelNeon.jpg)


![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/EdgeDetection/EdgeDetectionSobelNeon/EdgeDetectionSobelNeon.gif)
