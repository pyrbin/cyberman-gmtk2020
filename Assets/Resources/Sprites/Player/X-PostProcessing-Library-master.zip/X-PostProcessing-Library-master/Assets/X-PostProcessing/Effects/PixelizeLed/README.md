
# Pixelize Led

## Source Code List
- [Shader Code](Shader/PixelizeLed.shader)
- [C# Code](PixelizeLed.cs)
- [Editor Code](Editor/PixelizeLedEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeLed/PixelizeLedProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeLed/PixelizeLed.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeLed/PixelizeLed.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeLed/PixelizeLed-2.gif)