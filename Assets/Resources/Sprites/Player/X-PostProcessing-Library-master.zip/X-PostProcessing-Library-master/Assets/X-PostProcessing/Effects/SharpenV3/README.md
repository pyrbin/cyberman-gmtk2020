
# SharpenV3

## Source Code List
- [Shader Code](Shader/SharpenV3.shader)
- [C# Code](SharpenV3.cs)
- [Editor Code](Editor/SharpenV3Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/ImageProcessing/SharpenV3/SharpenV3Property.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/ImageProcessing/SharpenV3/SharpenV3.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/ImageProcessing/SharpenV3/SharpenV3.gif)