
# RapidVignetteV2

## Source Code List
- [Shader Code](Shader/RapidVignetteV2.shader)
- [C# Code](RapidVignetteV2.cs)
- [Editor Code](Editor/RapidVignetteV2Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidVignetteV2/RapidVignetteV2Property.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidVignetteV2/RapidVignetteV2.png)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Vignette/RapidVignetteV2/RapidVignetteV2.gif)