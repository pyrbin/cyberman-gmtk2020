
# GlitchScreenJump

## Source Code List
- [Shader Code](Shader/GlitchScreenJump.shader)
- [C# Code](GlitchScreenJump.cs)
- [Editor Code](Editor/GlitchScreenJumpEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchScreenJump/GlitchScreenJump.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchScreenJump/GlitchScreenJump-1.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchScreenJump/GlitchScreenJump-2.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchScreenJump/GlitchScreenJump.gif)
