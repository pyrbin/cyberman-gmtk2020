
# GlitchRGBSplitV4

## Source Code List
- [Shader Code](Shader/GlitchRGBSplitV4.shader)
- [C# Code](GlitchRGBSplitV4.cs)
- [Editor Code](Editor/GlitchRGBSplitV4Editor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV4/GlitchRGBSplitV4.png)

## Gallery

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV4/GlitchRGBSplitV4-2.gif)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Glitch/GlitchRGBSplitV4/GlitchRGBSplitV4.gif)
