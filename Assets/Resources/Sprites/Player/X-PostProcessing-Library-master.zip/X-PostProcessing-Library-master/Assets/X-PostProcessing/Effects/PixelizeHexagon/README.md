
# Pixelize Hexagon

## Source Code List
- [Shader Code](Shader/PixelizeHexagon.shader)
- [C# Code](PixelizeHexagon.cs)
- [Editor Code](Editor/PixelizeHexagonEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeHexagon/PixelizeHexagonProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeHexagon/PixelizeHexagon.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeHexagon/PixelizeHexagon.gif)