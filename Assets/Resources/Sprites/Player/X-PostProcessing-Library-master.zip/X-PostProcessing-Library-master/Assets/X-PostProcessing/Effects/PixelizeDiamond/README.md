
# Pixelize Diamond

## Source Code List
- [Shader Code](Shader/PixelizeDiamond.shader)
- [C# Code](PixelizeDiamond.cs)
- [Editor Code](Editor/PixelizeDiamondEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeDiamond/PixelizeDiamondProperty.jpg)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeDiamond/PixelizeDiamond.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Pixelize/PixelizeDiamond/PixelizeDiamond.gif)