
# Tent Blur

## Source Code List
- [Shader Code](Shader/TentBlur.shader)
- [C# Code](TentBlur.cs)
- [Editor Code](Editor/TentBlurEditor.cs)


## Property
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TentBlur/TentBlurProperty.png)

## Gallery
![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TentBlur/TentBlur.jpg)

![](https://raw.githubusercontent.com/QianMo/X-PostProcessing-Gallery/master/Media/Blur/TentBlur/TentBlur.gif)